# U Downloader Android Project

## How to Build the APK (No PC / Android Studio Required)
1. Extract this ZIP file.
2. Create a new repository on [GitHub](https://github.com/new).
3. Upload all the extracted files and folders (make sure to include the `.github` folder) to your repository and commit them.
4. Go to the **Actions** tab in your GitHub repository.
5. Click on the **Build U Downloader APK** workflow run.
6. Once the build finishes (takes about 3-4 minutes), scroll down to the **Artifacts** section and download **U-Downloader-APK**.
