package com.udownloader.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class VideoItem(
    val id: String,
    val title: String,
    val url: String,
    val thumbnail: String,
    val uploader: String,
    val channelUrl: String,
    val duration: String,
    var isSelected: Boolean = false
)

data class DownloadedRecord(
    val title: String,
    val format: String,
    val filePath: String,
    val channelName: String,
    val channelUrl: String,
    val originalUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF6C63FF),
                    secondary = Color(0xFF03DAC5),
                    background = Color(0xFF0F0F14),
                    surface = Color(0xFF1C1C24)
                )
            ) {
                UDownloaderApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UDownloaderApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(0) }
    var urlInput by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf("Best Video (MP4)") }
    val formats = listOf("Best Video (MP4)", "High-Res 4K/1080p", "Short/Vertical Video", "Audio Only (MP3)")

    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("Ready • yt-dlp Engine Active") }
    var downloadProgress by remember { mutableStateOf(0f) }

    var channelName by remember { mutableStateOf("") }
    var channelUrl by remember { mutableStateOf("") }
    var channelVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }

    val downloadedList = remember { mutableStateListOf<DownloadedRecord>() }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel._NIGHTLY)
                withContext(Dispatchers.Main) {
                    statusMessage = "yt-dlp Engine Updated to Latest Version"
                }
            } catch (_: Exception) {}
        }
    }

    fun analyzeLink(inputUrl: String) {
        if (inputUrl.isBlank()) return
        scope.launch {
            isLoading = true
            statusMessage = "Analyzing link & extracting metadata..."
            withContext(Dispatchers.IO) {
                try {
                    val request = YoutubeDLRequest(inputUrl).apply {
                        addOption("--flat-playlist")
                        addOption("--dump-single-json")
                    }
                    val info = YoutubeDL.getInstance().getInfo(request)

                    if (inputUrl.contains("@") || inputUrl.contains("/channel/") || inputUrl.contains("/playlist") || inputUrl.contains("/c/")) {
                        val feedReq = YoutubeDLRequest(inputUrl).apply {
                            addOption("--flat-playlist")
                            addOption("--playlist-end", "30")
                        }
                        val entries = YoutubeDL.getInstance().getInfo(feedReq)
                        channelName = entries.uploader ?: entries.title ?: "Channel Profile"
                        channelUrl = inputUrl
                        channelVideos = listOf(
                            VideoItem(
                                id = info.id ?: "1",
                                title = info.title ?: "Channel Video Stream",
                                url = info.webpageUrl ?: inputUrl,
                                thumbnail = info.thumbnail ?: "",
                                uploader = channelName,
                                channelUrl = inputUrl,
                                duration = "${info.duration}s",
                                isSelected = true
                            )
                        )
                        withContext(Dispatchers.Main) {
                            statusMessage = "Channel loaded! Select videos to download."
                            currentTab = 1
                        }
                    } else {
                        val singleItem = VideoItem(
                            id = info.id ?: "0",
                            title = info.title ?: "Fetched Video",
                            url = inputUrl,
                            thumbnail = info.thumbnail ?: "",
                            uploader = info.uploader ?: "Unknown Creator",
                            channelUrl = info.uploaderUrl ?: inputUrl,
                            duration = "${info.duration}s",
                            isSelected = true
                        )
                        channelName = singleItem.uploader
                        channelUrl = singleItem.channelUrl
                        channelVideos = listOf(singleItem)
                        withContext(Dispatchers.Main) {
                            statusMessage = "Video ready: ${singleItem.title}"
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        statusMessage = "Error: ${e.localizedMessage ?: "Invalid URL"}"
                    }
                } finally {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            }
        }
    }

    fun startDownload(video: VideoItem) {
        scope.launch {
            isLoading = true
            downloadProgress = 0f
            statusMessage = "Downloading: ${video.title}"

            withContext(Dispatchers.IO) {
                try {
                    val downloadDir = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        "UDownloader"
                    )
                    if (!downloadDir.exists()) downloadDir.mkdirs()

                    val request = YoutubeDLRequest(video.url).apply {
                        addOption("-o", "${downloadDir.absolutePath}/%(title)s.%(ext)s")
                        when (selectedFormat) {
                            "Audio Only (MP3)" -> {
                                addOption("-x")
                                addOption("--audio-format", "mp3")
                            }
                            "High-Res 4K/1080p" -> {
                                addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best")
                            }
                            else -> {
                                addOption("-f", "best[ext=mp4]/best")
                            }
                        }
                    }

                    YoutubeDL.getInstance().execute(request) { progress, _, _ ->
                        downloadProgress = (progress / 100f).coerceIn(0f, 1f)
                    }

                    withContext(Dispatchers.Main) {
                        downloadedList.add(
                            0,
                            DownloadedRecord(
                                title = video.title,
                                format = selectedFormat,
                                filePath = downloadDir.absolutePath,
                                channelName = video.uploader,
                                channelUrl = video.channelUrl,
                                originalUrl = video.url
                            )
                        )
                        statusMessage = "Download Complete! Saved to Downloads/UDownloader"
                        Toast.makeText(context, "Saved: ${video.title}", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        statusMessage = "Download Failed: ${e.localizedMessage}"
                    }
                } finally {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color(0xFF6C63FF))
                        Spacer(Modifier.width(8.dp))
                        Text("U Downloader", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            withContext(Dispatchers.Main) { statusMessage = "Checking for yt-dlp updates..." }
                            try {
                                YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel._NIGHTLY)
                                withContext(Dispatchers.Main) {
                                    statusMessage = "yt-dlp updated to latest!"
                                    Toast.makeText(context, "yt-dlp Engine Updated!", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) { statusMessage = "Update check complete." }
                            }
                        }
                    }) {
                        Icon(Icons.Default.SystemUpdateAlt, contentDescription = "Update yt-dlp", tint = Color(0xFF03DAC5))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1C1C24))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF1C1C24)) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    label = { Text("Downloader") }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = null) },
                    label = { Text("Channel Profile") }
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.FolderSpecial, contentDescription = null) },
                    label = { Text("Downloaded (${downloadedList.size})") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F0F14))
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C24)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(statusMessage, color = Color(0xFF03DAC5), fontSize = 13.sp)
                    if (isLoading) {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { if (downloadProgress > 0f) downloadProgress else 0.5f },
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF6C63FF)
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            when (currentTab) {
                0 -> {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("Paste Video, Short, or Channel Link (All Platforms)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        trailingIcon = {
                            if (urlInput.isNotEmpty()) {
                                IconButton(onClick = { urlInput = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        }
                    )

                    Spacer(Modifier.height(12.dp))

                    Text("Select Format & Quality:", color = Color.Gray, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        formats.take(2).forEach { fmt ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt },
                                label = { Text(fmt, fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        formats.drop(2).forEach { fmt ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt },
                                label = { Text(fmt, fontSize = 12.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { analyzeLink(urlInput) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B2B36))
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Open Channel / Info")
                        }

                        Button(
                            onClick = {
                                if (urlInput.isNotBlank()) {
                                    startDownload(
                                        VideoItem(
                                            id = "quick",
                                            title = "Direct Video (${System.currentTimeMillis() / 1000})",
                                            url = urlInput,
                                            thumbnail = "",
                                            uploader = "Direct Link",
                                            channelUrl = urlInput,
                                            duration = "Auto"
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C63FF))
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Quick Download")
                        }
                    }
                }

                1 -> {
                    if (channelVideos.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Paste a Channel or Video Link in the Downloader tab first.", color = Color.Gray)
                        }
                    } else {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF252530)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Color(0xFF6C63FF), modifier = Modifier.size(48.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(channelName, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                                    Text(channelUrl, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Button(
                                    onClick = {
                                        channelVideos.filter { it.isSelected }.forEach { startDownload(it) }
                                    }
                                ) {
                                    Text("Download Selected")
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(channelVideos) { video ->
                                var checked by remember { mutableStateOf(video.isSelected) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C24)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = checked,
                                            onCheckedChange = {
                                                checked = it
                                                video.isSelected = it
                                            }
                                        )
                                        AsyncImage(
                                            model = video.thumbnail,
                                            contentDescription = null,
                                            modifier = Modifier
                                                .size(80.dp, 50.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color.DarkGray),
                                            contentScale = ContentScale.Crop
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(video.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 2)
                                            Text("Duration: ${video.duration}", color = Color.Gray, fontSize = 12.sp)
                                        }
                                        IconButton(onClick = { startDownload(video) }) {
                                            Icon(Icons.Default.Download, contentDescription = "Download", tint = Color(0xFF03DAC5))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    if (downloadedList.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No videos downloaded yet.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(downloadedList) { item ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C24)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(item.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                                        Spacer(Modifier.height(4.dp))
                                        Text("Format: ${item.format}", color = Color(0xFF03DAC5), fontSize = 12.sp)
                                        Text("Saved in: ${item.filePath}", color = Color.Gray, fontSize = 12.sp)
                                        Spacer(Modifier.height(8.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.clickable {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(item.channelUrl))
                                                context.startActivity(intent)
                                            }
                                        ) {
                                            Icon(Icons.Default.Link, contentDescription = null, tint = Color(0xFF6C63FF), modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                "Channel Link: ${item.channelUrl}",
                                                color = Color(0xFF6C63FF),
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
